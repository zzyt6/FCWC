import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python'))
from hybrid_deploy import protocol as p
from hybrid_deploy.policy import Policy, Observations, Commands, read_bundle, targets
from hybrid_deploy.configuration import load_config


def state(cfg):
    return p.State(42,1,1000000000,1,0,1,0,1,
                   np.asarray(cfg['default_q_sdk29'],dtype=np.float32),np.zeros(29,dtype=np.float32),
                   np.zeros(3,dtype=np.float32),np.array([1,0,0,0],dtype=np.float32),
                   np.zeros(3,dtype=np.float32),np.zeros(4,dtype=np.float32),
                   np.asarray(cfg['default_q_sdk29'],dtype=np.float32))


class HybridTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cfg,cls.contract,_=read_bundle(ROOT)
        cls.policy=Policy(ROOT,cls.cfg)

    def test_profile_wire_and_pd_feedback_roundtrip(self):
        self.assertEqual(p.STATE.size,700);self.assertEqual(p.COMMAND.size,172)
        s=state(self.cfg)
        data=p.STATE.pack(p.STATE_MAGIC,p.VERSION,s.session,s.sequence,s.received_ns,s.config_token,
                          s.stage,s.flags,s.buttons,s.mode_machine,*np.arange(101),1,.5,
                          *np.arange(29),*np.ones(29))
        decoded=p.State.decode(data)
        np.testing.assert_array_equal(decoded.q,np.arange(29))
        np.testing.assert_array_equal(decoded.applied_q,np.arange(72,101))
        np.testing.assert_array_equal(decoded.applied_kp,np.arange(29))
        self.assertEqual(decoded.profile,1);self.assertEqual(decoded.gain_blend,.5)
        values=p.COMMAND.unpack(p.command(s,3,p.RUN,s.q,profile=1))
        self.assertEqual(values[7:9],(p.RUN,1))
        with self.assertRaises(ValueError):p.command(s,4,p.RUN,s.q,profile=2)
        for raw in (bytes(460),bytes(700)):
            with self.assertRaises(ValueError):p.State.decode(raw)

    def test_model_selection_boundary_and_forced_modes(self):
        for cmd,expected in [([0,0,0],'balance'),([.049,0,0],'balance'),([.05,0,0],'homie'),
                             ([0,-.051,0],'homie'),([0,0,.051],'homie'),([0,0,0],'balance')]:
            self.assertEqual(self.policy.select(cmd),expected)
        for mode in ('balance','homie'):
            policy=Policy(ROOT,self.cfg,policy_mode=mode)
            for cmd in ([0,0,0],[.3,-.3,.5]):self.assertEqual(policy.select(cmd),mode)
        with self.assertRaises(ValueError):Policy(ROOT,self.cfg,policy_mode='walk')
        with self.assertRaises(ValueError):self.policy.select([0,np.inf,0])

    def test_both_models_match_original_export_vectors(self):
        for name in ('balance','homie'):
            with np.load(ROOT/'models'/name/'verification_vectors.npz',allow_pickle=False) as data:
                expected=data['balance_actions' if name=='balance' else 'actions']
                for obs,action in zip(data['observations'],expected):
                    np.testing.assert_allclose(self.policy.infer(name,obs.reshape(1,-1)),action,rtol=1e-5,atol=1e-5)

    def test_independent_histories_match_original_adapters_through_switches(self):
        references={}
        for name in ('balance','homie'):
            spec=importlib.util.spec_from_file_location(name+'_reference',ROOT/'reference_adapters'/f'{name}_policy.py')
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            references[name]=module.Observations(self.contract[name])
        actual=Observations(self.contract);rng=np.random.default_rng(17)
        modes=[]
        for i in range(40):
            s=state(self.cfg);s.q+=rng.normal(0,.02,29).astype(np.float32)
            s.dq=rng.normal(0,.1,29).astype(np.float32);s.omega=rng.normal(0,.1,3).astype(np.float32)
            s.applied_q+=rng.normal(0,.01,29).astype(np.float32)
            velocity=np.array([0,0,0] if i%8<4 else [.12,-.08,.1],dtype=np.float32)
            obs=actual.push(s,velocity,.74,[0,0,0])
            expected={'balance':references['balance'].push(s,velocity,.74,[0,0,0]),
                      'homie':references['homie'].push(s,velocity,.74)}
            for name in expected:np.testing.assert_array_equal(obs[name],expected[name])
            actions=self.policy(obs,velocity);modes.append(self.policy.selected)
            actual.record_action(actions);references['balance'].record_action(actions['balance'])
        self.assertEqual(set(modes),{'balance','homie'})
        self.assertEqual(actual.frames,40)
        self.assertEqual(actual.models['balance'].history.shape,(6,86))
        self.assertEqual(actual.models['homie'].history.shape,(6,76))
        actual.reset();self.assertEqual(actual.frames,0)
        self.assertFalse(actual.models['balance'].previous_action.any())

    def test_distinct_waist_observation_and_action_mapping(self):
        s=state(self.cfg);s.q[13:15]=[.2,-.2]
        obs=Observations(self.contract).push(s,[0,0,0],.74,[0,0,0])
        np.testing.assert_allclose(obs['balance'][0,-86+26:-86+28],[.2,-.2])
        np.testing.assert_array_equal(obs['homie'][0,-76+10:-76+37],np.zeros(27))
        s.applied_q[12:]=.12
        homie=targets(np.zeros(12),s,self.cfg,self.contract,'homie')
        balance=targets(np.zeros(15),s,self.cfg,self.contract,'balance')
        np.testing.assert_array_equal(homie[12:],s.applied_q[12:])
        np.testing.assert_array_equal(balance[12:15],np.zeros(3))
        np.testing.assert_array_equal(balance[15:],s.applied_q[15:])
        np.testing.assert_array_equal(homie[:12],np.array(self.cfg['default_q_sdk29'][:12],dtype=np.float32))

    def test_independent_pd_edits_change_combined_token(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);shutil.copytree(ROOT/'config',root/'config')
            cfg,pd,token=load_config(root)
            self.assertNotEqual(pd['balance']['kp_sdk29'],pd['homie']['kp_sdk29'])
            for name in ('balance','homie'):
                path=root/cfg['pd_files'][name];original=path.read_text();data=json.loads(original)
                data['kp_sdk29'][0]+=1;path.write_text(json.dumps(data))
                _,gains,new=load_config(root)
                self.assertNotEqual(new,token)
                other='balance' if name=='homie' else 'homie'
                self.assertEqual(gains[other],pd[other])
                path.write_text(original)
            path=root/cfg['pd_files']['homie'];data=json.loads(path.read_text());data['kd_sdk29'][14]=-1
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):load_config(root)

    def test_bad_inputs(self):
        with self.assertRaises(ValueError):self.policy.infer('homie',np.zeros((1,516)))
        with self.assertRaises(ValueError):self.policy.infer('balance',np.full((1,516),np.nan))
        with self.assertRaises(ValueError):targets(np.zeros(15),state(self.cfg),self.cfg,self.contract,'homie')

    def test_command_zero_and_slew(self):
        s=state(self.cfg);s.sticks[:]=[0,1,0,0];cmd=Commands(self.cfg)
        np.testing.assert_array_equal(cmd.update(s,.02),[0,0,0])
        s.buttons=p.L1;out=cmd.update(s,.02);self.assertTrue(0<out[0]<=.006001)
        s.buttons=p.B|p.L1;np.testing.assert_array_equal(cmd.update(s,.02),[0,0,0])


if __name__=='__main__':unittest.main()
