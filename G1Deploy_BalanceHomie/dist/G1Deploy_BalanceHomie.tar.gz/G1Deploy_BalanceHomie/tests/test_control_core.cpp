#include "control_core.hpp"
#include <cassert>
#include <iostream>
#include <limits>

using namespace decoupled;
struct Fixture {
  ControlCore core{42}; Feedback f; uint64_t now=1000000000ULL,sequence=0;
  Fixture() {
    f.valid=true; f.remote_valid=true; f.packet.received_ns=now; f.packet.sequence=1;
    f.packet.quaternion[0]=1;
    for(int i=0;i<29;++i) f.packet.q[i]=config::default_q_sdk29[i];
  }
  void advance(double seconds=0.005) {
    now+=uint64_t(seconds*1e9); f.packet.received_ns=now; ++f.packet.sequence;
  }
  CommandPacket packet(Request request) {
    CommandPacket c; c.session=42; c.sequence=++sequence; c.config_token=config::token;
    c.observed_sequence=f.packet.sequence; c.observed_received_ns=f.packet.received_ns;
    c.request=static_cast<uint32_t>(request);
    for(int i=0;i<29;++i) c.q[i]=config::default_q_sdk29[i];
    return c;
  }
  void send(Request r) { assert(core.command(packet(r),f,now)); }
  void holding() {
    send(Request::Prepare); core.step(f,now);
    for(int i=0;i<620;++i) {
      advance(); send(Request::Prepare); auto out=core.step(f,now);
      for(int j=0;j<29;++j) f.packet.q[j]=out.q[j];
    }
    assert(core.stage==Stage::Holding);
  }
};
int main() {
  { Fixture x; for(int i=0;i<100;++i) { x.advance(); assert(!x.core.step(x.f,x.now).publish); }
    x.send(Request::Policy); assert(!x.core.ever_enabled); }
  { Fixture x; auto c=x.packet(Request::Prepare); c.session=99;
    assert(!x.core.command(c,x.f,x.now)); assert(!x.core.ever_enabled); }
  { Fixture x; auto c=x.packet(Request::Prepare); c.config_token++;
    assert(!x.core.command(c,x.f,x.now)); assert(!x.core.ever_enabled); }
  { Fixture x; auto c=x.packet(Request::Prepare); c.q[0]=std::numeric_limits<float>::quiet_NaN();
    assert(!x.core.command(c,x.f,x.now)); assert(!x.core.ever_enabled); }
  { Fixture x; x.f.packet.received_ns-=200000000;
    assert(!x.core.command(x.packet(Request::Prepare),x.f,x.now)); assert(!x.core.ever_enabled); }
  { Fixture x; x.f.packet.q[0]=0.4; x.f.packet.q[15]=0.25; x.f.packet.q[13]=0.1; x.holding();
    auto out=x.core.step(x.f,x.now);
    for(int i=0;i<15;++i) assert(std::abs(out.q[i]-config::default_q_sdk29[i])<1e-5);
    assert(std::abs(out.q[15]-0.25)<1e-5); assert(std::abs(out.q[13])<1e-5);
    assert(out.kp[0]==config::balance_kp_sdk29[0] && out.kp[3]==config::balance_kp_sdk29[3]); }
  { Fixture x; x.holding(); auto before=x.core.step(x.f,x.now); x.advance();
    auto c=x.packet(Request::Policy); c.q[0]+=1;
    assert(x.core.command(c,x.f,x.now)); auto after=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Policy);
    assert(after.q[0]>before.q[0] && after.q[0]-before.q[0]<=0.05001); }
  { Fixture x; x.holding(); x.advance(0.2); auto out=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault && out.publish && out.kp[0]==0 && out.kd[0]==2);
    assert(!x.core.command(x.packet(Request::Prepare),x.f,x.now)); }
  { Fixture x; x.holding(); x.now+=200000000; auto out=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault && out.kp[0]==0); }
  { Fixture x; x.holding(); x.f.packet.buttons=kL2; auto out=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Damped && out.kp[0]==0); }
  { Fixture x; x.holding(); x.f.packet.rpy[0]=1.; x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault); }
  { Fixture x; x.holding(); x.f.motor_error=true; x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault); }
  { Fixture x; x.holding(); x.f.max_temperature=90; x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault); }
  { Fixture x; x.holding(); x.f.remote_valid=false; x.core.step(x.f,x.now);
    assert(x.core.stage==(config::require_remote_heartbeat?Stage::Fault:Stage::Holding)); }
  { Fixture x; x.holding(); auto c=x.packet(Request::Hold); assert(x.core.command(c,x.f,x.now));
    assert(!x.core.command(c,x.f,x.now)); }
  { Fixture x; x.holding(); auto c=x.packet(Request::Policy); c.q[0]=5;
    assert(!x.core.command(c,x.f,x.now)); assert(x.core.stage==Stage::Fault); }
  { Fixture x; x.holding();
    for(int i=0;i<40;++i) {
      x.advance(); auto c=x.packet(Request::Policy); c.q[0]=2.5;
      assert(x.core.command(c,x.f,x.now)); auto out=x.core.step(x.f,x.now);
      assert(std::abs(out.kp[0]*(out.q[0]-x.f.packet.q[0])-out.kd[0]*x.f.packet.dq[0])<=88.001);
    } }
  { Fixture x; x.holding(); x.f.packet.dq[0]=500; auto out=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault && out.kp[0]==0); }
  { Fixture x; x.f.packet.q[0]=0.4; x.send(Request::Prepare); x.core.step(x.f,x.now);
    for(int i=0;i<1000;++i) { x.advance(); x.send(Request::Prepare); x.core.step(x.f,x.now); }
    assert(x.core.stage==Stage::Ramping);
    x.advance(5.1); x.send(Request::Prepare); auto out=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault && out.kp[0]==0); }
  { Fixture x; x.holding(); auto before=x.core.step(x.f,x.now); x.advance();
    auto c=x.packet(Request::Policy); c.q[12]=0.2; c.q[13]=0.1; c.q[14]=-0.1; c.q[15]=0.4;
    assert(x.core.command(c,x.f,x.now)); auto after=x.core.step(x.f,x.now);
    assert(after.q[12]>before.q[12] && after.q[13]>before.q[13] && after.q[14]<before.q[14]);
    assert(after.q[15]==before.q[15]);
    assert(after.kp[14]==config::balance_kp_sdk29[14] && after.kd[14]==config::balance_kd_sdk29[14]); }
  { Fixture x; x.f.remote_valid=false; std::string reason;
    ControlCore required(42,true), ignored(42,false);
    assert(!required.healthy(x.f,x.now,&reason));
    assert(reason=="wirelesscontroller_missing_or_stale");
    assert(ignored.healthy(x.f,x.now));
    x.f.packet.received_ns-=200000000;
    assert(!ignored.healthy(x.f,x.now,&reason));
    assert(reason=="lowstate_missing_or_stale"); }
  { Fixture x; x.core=ControlCore(42,false); x.f.remote_valid=false; x.holding();
    x.f.packet.buttons=kL2; auto out=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Damped && out.kp[0]==0 && out.kd[0]==2); }
  { Fixture x; x.core=ControlCore(42,false); x.f.remote_valid=false; x.holding();
    x.f.packet.received_ns=x.now+1; x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault);
    assert(x.core.reason.find("lowstate_timestamp_in_future")!=std::string::npos); }
  { Fixture x; x.f.packet.q[14]=.2; x.send(Request::Prepare); x.core.step(x.f,x.now);
    auto diagnostic=x.core.calibration_diagnostics(x.f,x.now);
    assert(diagnostic.find("index=14")!=std::string::npos); }
  { Fixture x; x.holding(); x.send(Request::Policy); auto before=x.core.step(x.f,x.now);
    x.advance(); auto c=x.packet(Request::Policy); c.profile=1; c.q[0]+=.2;
    c.q[12]=.4; c.q[13]=.3; c.q[14]=.3; c.q[15]=.5;
    assert(x.core.command(c,x.f,x.now)); auto first=x.core.step(x.f,x.now);
    assert(first.profile==1 && first.gain_blend==0);
    for(int j=0;j<29;++j) {
      assert(first.q[j]==before.q[j]); assert(first.kp[j]==before.kp[j]); assert(first.kd[j]==before.kd[j]);
    }
    for(int i=0;i<120;++i) {
      x.advance(); c.sequence=++x.sequence; c.observed_sequence=x.f.packet.sequence;
      c.observed_received_ns=x.f.packet.received_ns; assert(x.core.command(c,x.f,x.now));
      auto out=x.core.step(x.f,x.now);
      for(int j=0;j<29;++j) x.f.packet.q[j]=out.q[j];
    }
    auto out=x.core.step(x.f,x.now); assert(out.gain_blend==1);
    for(int j=0;j<29;++j) {
      assert(std::abs(out.kp[j]-config::homie_kp_sdk29[j])<1e-5);
      assert(std::abs(out.kd[j]-config::homie_kd_sdk29[j])<1e-5);
    }
    for(int j=12;j<29;++j) assert(out.q[j]==before.q[j]);
    assert(out.q[0]>before.q[0]+.19);
    x.advance(); c=x.packet(Request::Policy); c.profile=0; c.q[13]=.1;
    assert(x.core.command(c,x.f,x.now)); auto back=x.core.step(x.f,x.now);
    assert(back.kp==out.kp && back.q==out.q && back.gain_blend==0);
    for(int i=0;i<120;++i) {
      x.advance(); c.sequence=++x.sequence; c.observed_sequence=x.f.packet.sequence;
      c.observed_received_ns=x.f.packet.received_ns; assert(x.core.command(c,x.f,x.now));
      auto v=x.core.step(x.f,x.now);for(int j=0;j<29;++j)x.f.packet.q[j]=v.q[j];
    }
    back=x.core.step(x.f,x.now);assert(std::abs(back.q[13]-.1)<1e-5);
    assert(back.kp==config::balance_kp_sdk29 && back.kd==config::balance_kd_sdk29); }
  { Fixture x; x.holding(); auto out=x.core.step(x.f,x.now);
    for(int i=0;i<60;++i) {
      x.advance(); auto c=x.packet(Request::Policy); c.profile=(i/4)%2; c.q[0]+=.2;
      assert(x.core.command(c,x.f,x.now)); auto next=x.core.step(x.f,x.now);
      for(int j=0;j<29;++j) {
        assert(std::abs(next.q[j]-out.q[j])<=.05001);
        assert(std::abs(next.kp[j]-out.kp[j])<5);
        x.f.packet.q[j]=next.q[j];
      }
      out=next;
    }
    x.advance(.2); auto stopped=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Fault && stopped.kp[0]==0 && stopped.kd[0]==config::damping_kd); }
  { Fixture x; x.holding();auto c=x.packet(Request::Policy);c.profile=99;
    assert(!x.core.command(c,x.f,x.now));assert(x.core.stage==Stage::Fault); }
  { Fixture x; x.holding();auto c=x.packet(Request::Policy);c.profile=1;
    assert(x.core.command(c,x.f,x.now));x.core.step(x.f,x.now);
    x.f.packet.buttons=kL2;auto out=x.core.step(x.f,x.now);
    assert(x.core.stage==Stage::Damped && out.kp[0]==0 && out.kd[0]==config::damping_kd); }
  std::cout<<"28 control-core scenarios passed\n";
}
