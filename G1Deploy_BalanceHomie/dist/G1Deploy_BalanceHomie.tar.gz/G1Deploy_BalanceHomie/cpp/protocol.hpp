#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include <cmath>

namespace decoupled {
constexpr uint32_t kStateMagic = 0x48594253, kCommandMagic = 0x48594243, kVersion = 1;
constexpr uint32_t kR2 = 1U << 4, kL2 = 1U << 5, kB = 1U << 9;
enum class Stage : uint32_t { Waiting=0, Ramping=1, Holding=2, Policy=3, Damped=4, Fault=5 };
enum class Request : uint32_t { Wait=0, Prepare=1, Hold=2, Policy=3, Stop=4 };
enum class Profile : uint32_t { Balance=0, Homie=1 };

// 只在同一台 Linux 主机的 loopback 上通信，x86_64/aarch64 均为 little-endian。
#pragma pack(push, 1)
struct StatePacket {
  uint32_t magic=kStateMagic, version=kVersion;
  uint64_t session=0, sequence=0, received_ns=0, config_token=0;
  uint32_t stage=0, flags=0, buttons=0, mode_machine=0;
  float q[29]{}, dq[29]{}, omega[3]{}, quaternion[4]{}, rpy[3]{}, sticks[4]{}, applied_q[29]{};
  uint32_t profile=0;
  float gain_blend=1, applied_kp[29]{}, applied_kd[29]{};
};
struct CommandPacket {
  uint32_t magic=kCommandMagic, version=kVersion;
  uint64_t session=0, sequence=0, observed_sequence=0, observed_received_ns=0, config_token=0;
  uint32_t request=0, profile=0;
  float q[29]{};
};
#pragma pack(pop)
static_assert(sizeof(StatePacket)==700, "State wire format changed");
static_assert(sizeof(CommandPacket)==172, "Command wire format changed");

struct Feedback {
  StatePacket packet;
  bool valid=false;
  bool motor_error=false;
  bool remote_valid=false;
  uint64_t remote_received_ns=0;
  float max_temperature=0;
};
struct Output {
  bool publish=false;
  std::array<float,29> q{}, kp{}, kd{};
  uint32_t profile=0;
  float gain_blend=1;
};
inline uint32_t crc32(const void* data, size_t bytes) {
  uint32_t crc=0xffffffff;
  auto p=static_cast<const unsigned char*>(data);
  for(size_t i=0;i<bytes;i+=4) {
    uint32_t word; std::memcpy(&word,p+i,4);
    for(uint32_t bit=0x80000000;bit;bit>>=1) {
      bool high=crc&0x80000000; crc<<=1;
      if(high) crc^=0x04c11db7;
      if(word&bit) crc^=0x04c11db7;
    }
  }
  return crc;
}
}
