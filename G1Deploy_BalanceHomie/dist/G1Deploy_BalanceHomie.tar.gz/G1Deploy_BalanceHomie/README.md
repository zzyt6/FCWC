# G1 Balance + Homie 混合部署包

低速使用 `G1Deploy_DecoupledWBC` 的 Balance ONNX，行走使用 `G1Deploy_Homie60000` 当前 60000 轮 ONNX。模型字节原样复制，两个原部署目录无需修改，也不参与本包运行。

## 启动与网页操作

网页统一使用相邻 **`../Viser`** 目录，原内置 `visualizer.py` 已删除。完整的页面操作、单腰映射与自动存档见 [外层 Viser 说明](../Viser/README.md)。

```bash
cd /home/unitree/CWC
bash Viser/run.sh --mode sim --port 8086                    # 合成反馈联调，不是物理仿真
bash Viser/run.sh --mode observe --interface eth0 --port 8086 # 真机只读
bash Viser/run.sh --mode control --interface eth0 --port 8086 # 真机控制，页面显式接管
```

旧 `bash run.sh shadow/control eth0 --viser --viser-port 8085` 和 `bash run.sh simulate-web --viser --viser-port 8085` 也会转到这个外层网页。网页启动先只读，点击“① 接管底层”后才释放原厂控制器；依次准备姿态、启动混合策略。外层维持单腰 27 轴，禁用 SDK 13/14，不压缩后续索引，observe/control 自动生成独立会话存档。

本包仍可独立运行无网页部署，沿用原 29 轴控制配置：

```bash
conda activate CWC
cd /home/unitree/CWC/G1Deploy_BalanceHomie
bash run.sh shadow eth0
bash run.sh control eth0 --log reports/control_hybrid.jsonl
bash run.sh simulate
```

无网页 `control` 启动时即释放原厂控制器；R2 准备、R2 启动策略、L1+摇杆运动、B 归零、L2 停止。请勿同时运行本包和外层 Viser，它们独占相同的 UDP 27001/27002。停止使用 L2 或 Ctrl+C；Kp=0、Kd=2 退出阻尼不维持站立，需要支撑。

安装无网页依赖使用 `bash setup.sh`，网页依赖使用 `bash ../Viser/setup.sh`。迁移网页时须一起复制 `Viser`、本包和 `G1_URDF`。

## 切换规则及控制范围

`config/deploy.json` 中 `model_switch_command_norm=0.05`：

- `norm([vx,vy,wz]) < 0.05`：Balance；等于或大于阈值：Homie。
- 使用经过指令限幅/加速率限制、尚未进行模型输入缩放的速度**命令**，不是实测机身速度。该范数沿用 WBC 定义，包含转向命令。
- 不加滞回；阈值附近来回变化会重复切换。每次从最近下发的目标和增益继续过渡。
- `--policy-mode auto` 是默认值；可用 `--policy-mode balance` 或 `--policy-mode homie` 做单模型对比。此选项只控制模型选择，准备阶段始终使用 Balance PD。重启时恢复 auto 即可。

| 项目 | Balance | Homie |
| --- | --- | --- |
| ONNX | `models/balance/policy.onnx` | `models/homie/policy.onnx` |
| 输入/动作维度 | 516 / 15 | 456 / 12 |
| 观测历史 | 独立的 6×86 | 独立的 6×76 |
| 关节观测 | SDK 0–28 全部 29 关节 | SDK 0–12、15–28，跳过腰 roll/pitch |
| previous action | 本模型上次原始输出，15 维 | 当前反馈内已限幅腿部目标反算，12 维 |
| 策略控制范围 | 双腿 + 腰 yaw/roll/pitch | 双腿；腰保持进入 Homie 时的 C++ 输出目标 |
| 双臂 | 保持第一次准备时捕获的目标 | 保持同一捕获目标，使用 Homie 的臂部 PD |
| 动作缩放 | 0.25 | 0.25 |

准备阶段采用 Balance PD，对腿和腰共 15 关节做至少 3 秒准备；准备姿态和到位条件沿用 WBC。进入 POLICY 后才执行模型动作。

两套观测从同一实测反馈分别构造，不拼接或混用 516/456 维数据。WAITING/HOLDING/POLICY 的每个推理周期均计算两个模型，持续更新各自历史；RAMPING 暂停推理，阶段变更按原规则清空历史。只有被选中的目标送给桥接；Balance 未选中时保存的是自身影子推理输出作为 previous action。这样避免切换时使用停留在数秒之前的观测，也不把另一模型的输出冒充本模型历史。任一模型输入/输出异常均停止整个控制。

切到 Homie 时，C++ 冻结当时腰部的已下发目标，忽略 Homie 请求中的腰和双臂目标，防止 12/15 维映射混用。这个腰姿态可能不为中立位，是混合部署相对原 Homie 训练结构的一项差异。返回 Balance 后腰恢复由 Balance 控制。

## 两套独立 Kp/Kd

- **Balance：`config/balance_pd.json`**，复制自 DecoupledWBC 当前配置。
- **Homie：`config/homie_pd.json`**，复制自 Homie60000 已恢复的原始配置。
- 两个文件都含 SDK 29 关节名称、`kp_sdk29`、`kd_sdk29`，包括腿、腰和双臂。修改一个文件不改变另一个。

以下左右对称的部位按单侧顺序列出：

| 部位/顺序 | Balance Kp | Balance Kd | Homie Kp | Homie Kd |
| --- | --- | --- | --- | --- |
| 髋 pitch/roll/yaw | 150 / 150 / 150 | 2 / 2 / 2 | 100 / 100 / 100 | 2 / 2 / 2 |
| 膝 | 200 | 4 | 150 | 4 |
| 踝 pitch/roll | 40 / 40 | 2 / 2 | 40 / 40 | 2 / 2 |
| 腰 yaw/roll/pitch | 250 / 250 / 250 | 5 / 5 / 5 | 300 / 300 / 300 | 5 / 5 / 5 |
| 肩 pitch/roll/yaw | 100 / 100 / 40 | 5 / 5 / 2 | 200 / 200 / 200 | 4 / 4 / 4 |
| 肘 | 40 | 2 | 100 | 1 |
| 腕 roll/pitch/yaw | 20 / 20 / 20 | 2 / 2 / 2 | 20 / 20 / 20 | 0.5 / 0.5 / 0.5 |

切换请求通过新的本机协议携带 profile 编号（Balance=0，Homie=1）。C++ 在 200 Hz 循环里选择配置，不接受 Python 任意传入的增益。`profile_transition_s=0.5` 表示从切换前输出目标/增益，以平滑曲线过渡到新模型当前目标和新 PD；目标速度、关节位置、估算 PD 力矩保护继续生效。

过渡时的增益是两配置之间的中间值，完成后才完整使用目标配置。两套 PD 的解耦不表示两套控制器同时发布 LowCmd；始终只有一个底层发布器。公共关节限位、effort、准备时序和健康阈值保留在 `config/deploy.json`，effort 沿用 WBC 的较小限制，避免切换时放宽力矩限制。

**修改任何配置后停止并重启程序**，`run.sh` 自动重新构建。公共配置和两个 PD 文件一起计算配置摘要，Python 与 C++ 不一致时拒绝运行；不支持运行中热更新。构建脚本也可显式运行 `bash build.sh`。

## 日志与复核

`--log reports/control_hybrid.jsonl` 保存约 50 Hz 的：29 关节 q/dq、IMU、速度命令、被选模型、模型原始动作、完整的两套观测历史、两套影子动作、Python 请求目标、C++ 反馈目标、实际下发 Kp/Kd、profile 和过渡进度，以及单调时间戳。无网页入口文件名固定时再次运行会覆盖；留存对比时换新名字。外层 Viser 自动会话及显式导出不覆盖旧数据。

- `selected_model`：本次 Python 选中的模型。
- `pd_profile`：已收到的反馈中 C++ 接受的模型编号。反馈采样早于本次请求，切换附近可能落后一个控制周期。
- `pd_transition_blend`：0 表示刚开始交接，1 表示已完成；等待阶段为 1，不代表正在发电机命令。
- `applied_kp_sdk29` / `applied_kd_sdk29`：反馈包内对应的输出增益，准备阶段反映增益渐变。
- `model_observations.balance` / `.homie`：完整 516 / 456 维历史；RAMPING 为 null。
- 同名 `.metadata.json` 保存本次公共配置、两套 PD、模型契约及模型 SHA256。

只有 POLICY 阶段执行选中模型动作，WAITING/HOLDING 中的模型动作属于影子推理。日志不是全部 200 Hz LowCmd 抓包，也没有机身真实位置/线速度，不能靠模型输出幅值判断漂移。

```bash
python tools/verify_model.py
python tools/test_offline.py
python tools/test_viser_offline.py
python tools/check_bundle.py
# 用当前模型/配置重放日志中的两套输入，并核对已完成的 PD 切换
python tools/verify_telemetry.py reports/control_hybrid.jsonl
```

验证使用固定向量、原观测代码对比、C++ 状态机以及合成反馈网页通信，不证明机器人上闭环稳定。验证报告在 `reports/`。`tools/package.py` 可生成带 SHA256 的无网页部署压缩包（不含本机 build/运行日志、相邻 Viser/G1_URDF）；新电脑解包后需要重新编译。
