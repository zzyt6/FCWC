import numpy as np

class Observations:
    def __init__(self, contract):
        self.contract = contract
        self.indices = np.asarray(contract['sdk29_indices'])
        self.default = np.asarray(contract['default_joint_positions'], dtype=np.float32)
        self.history = np.zeros((6, 86), dtype=np.float32)
        self.previous_action = np.zeros(15, dtype=np.float32)
        self.frames = 0

    def reset(self):
        self.history.fill(0)
        self.previous_action.fill(0)
        self.frames = 0

    def record_action(self, action):
        values = np.asarray(action, dtype=np.float32)
        if values.shape != (15,) or not np.isfinite(values).all():
            raise ValueError('Invalid previous action')
        # 上游使用原始网络动作，包括停用策略但继续推理的阶段；不反算限幅后的角度。
        self.previous_action[:] = values

    def push(self, state, velocity, height, torso_rpy):
        quat = np.asarray(state.quaternion, dtype=np.float64)
        norm = np.linalg.norm(quat)
        if not .8 < norm < 1.2:
            raise ValueError('Invalid IMU quaternion norm')
        w, x, y, z = quat / norm
        gravity = [2*(w*y-x*z), -2*(y*z+w*x), -(1-2*x*x-2*y*y)]
        spec = self.contract['input']
        scales = spec['observation_scales']
        frame = np.concatenate((
            np.asarray(velocity) * np.asarray(spec['command_scale']), [height],
            torso_rpy, state.omega * scales['ang_vel'], gravity,
            (state.q[self.indices] - self.default) * scales['dof_pos'],
            state.dq[self.indices] * scales['dof_vel'], self.previous_action,
        )).astype(np.float32)
        if frame.shape != (86,) or not np.isfinite(frame).all():
            raise ValueError('Invalid observation frame')
        self.history[:-1] = self.history[1:]
        self.history[-1] = frame
        self.frames += 1
        return self.history.reshape(1, 516)
