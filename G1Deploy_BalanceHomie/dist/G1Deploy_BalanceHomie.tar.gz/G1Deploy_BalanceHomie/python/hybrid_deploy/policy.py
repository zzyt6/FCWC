"""Independent Balance 516/15 and Homie 456/12 pipelines on shared measured feedback."""
import hashlib
import json
from pathlib import Path
import numpy as np
from .configuration import load_config, PROFILES
from .balance_observations import Observations as BalanceObservations
from .homie_observations import Observations as HomieObservations


def read_bundle(root):
    root = Path(root)
    cfg, _, token = load_config(root)
    contracts = {name: json.loads((root/cfg['contract_files'][name]).read_text()) for name in PROFILES}
    for name, inputs, outputs in [('balance',516,15),('homie',456,12)]:
        spec = contracts[name]
        if spec['input']['shape'] != [1,inputs] or spec['output']['shape'] != [1,outputs]:
            raise ValueError('Wrong model contract: '+name)
        if spec['input'].get('history_frames',spec['input'].get('history_len')) != 6 or spec['output']['action_scale'] != .25:
            raise ValueError('Unsupported history or action scale')
        indices = list(range(29)) if name == 'balance' else list(range(13))+list(range(15,29))
        if spec['sdk29_indices'] != indices:
            raise ValueError('Wrong SDK mapping: '+name)
        defaults = np.asarray(cfg['default_q_sdk29'])[indices]
        if not np.array_equal(defaults, spec['default_joint_positions']):
            raise ValueError('Calibration/default mismatch: '+name)
    # Existing web/calibration helpers need the common SDK names only.
    return cfg, dict(contracts, joint_names_sdk29=cfg['joint_names_sdk29']), token


class Policy:
    def __init__(self, root, cfg, policy_mode='auto'):
        if policy_mode not in ('auto','balance','homie'):
            raise ValueError('policy_mode must be auto, balance or homie')
        import onnxruntime as ort
        self.policy_mode = policy_mode
        self.root = Path(root)
        self.manifest = json.loads((self.root/'models/manifest.json').read_text())
        self.source_sha256 = self.manifest['model_sha256']
        for name, digest in self.manifest['artifact_sha256'].items():
            if hashlib.sha256((self.root/name).read_bytes()).hexdigest() != digest:
                raise ValueError('Artifact hash mismatch: '+name)
        options = ort.SessionOptions()
        options.intra_op_num_threads = options.inter_op_num_threads = 1
        self.sessions = {}
        for name, n_in, n_out in [('balance',516,15),('homie',456,12)]:
            if cfg['model_files'][name] != self.manifest['model_files'][name]:
                raise ValueError('Unexpected model path')
            session = ort.InferenceSession(str(self.root/cfg['model_files'][name]),
                                           sess_options=options, providers=['CPUExecutionProvider'])
            inp, out = session.get_inputs(), session.get_outputs()
            if (len(inp)!=1 or len(out)!=1 or len(inp[0].shape)!=2 or len(out[0].shape)!=2 or
                    inp[0].shape[-1]!=n_in or out[0].shape[-1]!=n_out or inp[0].type!='tensor(float)'):
                raise ValueError('Wrong ONNX interface: '+name)
            self.sessions[name] = session
        self.threshold = cfg['model_switch_command_norm']
        self.selected = 'homie' if policy_mode == 'homie' else 'balance'

    def select(self, velocity):
        value = np.asarray(velocity, dtype=np.float32)
        if value.shape != (3,) or not np.isfinite(value).all():
            raise ValueError('Invalid velocity command')
        self.selected = (self.policy_mode if self.policy_mode != 'auto' else
                         'balance' if np.linalg.norm(value) < self.threshold else 'homie')
        return self.selected

    def infer(self, name, observations):
        session = self.sessions[name]
        count = 516 if name == 'balance' else 456
        obs = np.asarray(observations, dtype=np.float32)
        if obs.shape != (1,count) or not np.isfinite(obs).all():
            raise ValueError('Invalid observation: '+name)
        action = session.run(None, {session.get_inputs()[0].name: obs})[0][0]
        if action.shape != ((15,) if name == 'balance' else (12,)) or not np.isfinite(action).all():
            raise ValueError('Invalid action: '+name)
        return action

    def __call__(self, observations, velocity):
        self.select(velocity)
        # Keep each model's own history/previous-action stream warm using real feedback.
        return {name:self.infer(name, observations[name]) for name in PROFILES}


class Observations:
    def __init__(self, contracts):
        self.models = {'balance': BalanceObservations(contracts['balance']),
                       'homie': HomieObservations(contracts['homie'])}

    @property
    def frames(self):
        return min(model.frames for model in self.models.values())

    def reset(self):
        for model in self.models.values():
            model.reset()

    def push(self, state, velocity, height, torso_rpy):
        return {'balance':self.models['balance'].push(state, velocity, height, torso_rpy),
                'homie':self.models['homie'].push(state, velocity, height)}

    def record_action(self, actions):
        self.models['balance'].record_action(actions['balance'])


def targets(action, state, cfg, contracts, selected):
    spec = contracts[selected]
    count = 15 if selected == 'balance' else 12
    action = np.asarray(action, dtype=np.float32)
    if action.shape != (count,) or not np.isfinite(action).all():
        raise ValueError('Invalid selected action')
    if selected == 'homie':
        action = np.clip(action, -spec['output']['training_clip_actions'], spec['output']['training_clip_actions'])
    q = state.applied_q.copy()
    q[:count] = np.asarray(spec['default_joint_positions'][:count]) + spec['output']['action_scale']*action
    return np.clip(q, cfg['joint_lower_sdk29'],cfg['joint_upper_sdk29']).astype(np.float32)


class Commands:
    def __init__(self, cfg):
        self.cfg = cfg
        self.value = np.zeros(3, dtype=np.float32)

    def update(self, state, dt):
        from .protocol import L1, B
        limits = np.asarray(self.cfg['command_limits'])
        lx, ly, rx, _ = state.sticks
        sticks = np.asarray([ly, -lx, -rx])
        deadzone = self.cfg['stick_deadzone']
        sticks = np.where(np.abs(sticks) < deadzone, 0,
                          np.sign(sticks) * (np.abs(sticks)-deadzone)/(1-deadzone))
        target = np.where(sticks >= 0, sticks * limits[:, 1], -sticks * limits[:, 0])
        if not state.buttons & L1 or state.buttons & B:
            target.fill(0)
        if state.buttons & B:
            self.value.fill(0)
        maximum = np.asarray(self.cfg['command_slew_per_s']) * min(dt, .04)
        self.value += np.clip(target-self.value, -maximum, maximum)
        return self.value.copy()
