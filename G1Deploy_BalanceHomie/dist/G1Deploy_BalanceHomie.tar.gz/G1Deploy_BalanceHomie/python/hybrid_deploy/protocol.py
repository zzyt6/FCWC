"""与 C++ 桥接共享的本机 UDP 格式；避免依赖 LCM/CUDA。"""
import struct
from dataclasses import dataclass, field
import numpy as np

STATE = struct.Struct('<IIQQQQIIII101fIf58f')
COMMAND = struct.Struct('<IIQQQQQII29f')
STATE_MAGIC, COMMAND_MAGIC, VERSION = 0x48594253, 0x48594243, 1
PROFILE_NAMES = ('balance', 'homie')
WAITING, RAMPING, HOLDING, POLICY, DAMPED, FAULT = range(6)
WAIT, PREPARE, HOLD, RUN, STOP = range(5)
R2, L2, B, L1 = 1 << 4, 1 << 5, 1 << 9, 1 << 1
STAGE_NAMES = ('WAITING', 'RAMPING', 'HOLDING', 'POLICY', 'DAMPED', 'FAULT')


@dataclass
class State:
    session: int
    sequence: int
    received_ns: int
    config_token: int
    stage: int
    flags: int
    buttons: int
    mode_machine: int
    q: np.ndarray
    dq: np.ndarray
    omega: np.ndarray
    quaternion: np.ndarray
    rpy: np.ndarray
    sticks: np.ndarray
    applied_q: np.ndarray
    profile: int = 0
    gain_blend: float = 1.
    applied_kp: np.ndarray = field(default_factory=lambda: np.zeros(29, dtype=np.float32))
    applied_kd: np.ndarray = field(default_factory=lambda: np.zeros(29, dtype=np.float32))

    @classmethod
    def decode(cls, data):
        if len(data) != STATE.size:
            raise ValueError('Wrong state packet size')
        v = STATE.unpack(data)
        if v[:2] != (STATE_MAGIC, VERSION) or v[6] > FAULT:
            raise ValueError('Wrong state protocol')
        floats = np.asarray(v[10:111], dtype=np.float32)
        if not np.isfinite(floats).all():
            raise ValueError('Non-finite feedback')
        gains = np.asarray(v[112:], dtype=np.float32)
        if v[111] > 1 or not np.isfinite(gains).all() or not 0 <= gains[0] <= 1 or (gains[1:] < 0).any():
            raise ValueError('Invalid profile/gain feedback')
        return cls(*v[2:10], floats[:29], floats[29:58], floats[58:61],
                   floats[61:65], floats[65:68], floats[68:72], floats[72:101],
                   v[111], float(gains[0]), gains[1:30], gains[30:59])


def command(state, sequence, request, targets, profile=0):
    q = np.asarray(targets, dtype=np.float32)
    if q.shape != (29,) or not np.isfinite(q).all():
        raise ValueError('Command must have 29 finite targets')
    if profile not in (0,1):
        raise ValueError('Invalid control profile')
    return COMMAND.pack(COMMAND_MAGIC, VERSION, state.session, sequence,
                        state.sequence, state.received_ns, state.config_token, request, profile, *q)
